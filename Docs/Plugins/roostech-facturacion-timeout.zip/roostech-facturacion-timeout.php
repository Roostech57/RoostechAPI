<?php
/*
Plugin Name: Roostech Facturación Electrónica
Description: Envía automáticamente datos de facturación al microservicio API Roostech 2 con control de timeout.
Version: 1.2
Author: Wilson Gallo
*/

// Confirmar que el plugin se ha cargado
error_log('Roostech Plugin cargado con timeout.');

// Función principal para enviar factura
function roostech_enviar_factura($cliente, $productos) {
    $url = 'https://aaa9-167-0-187-141.ngrok-free.app/facturar'; // Cambiar luego si se sube a servidor real

    $data = array(
        'token' => 'SECRETO123',
        'cliente' => array(
            'nombre' => $cliente['nombre'],
            'tipo_documento' => $cliente['tipo_documento'],
            'numero_documento' => $cliente['numero_documento'],
            'email' => $cliente['email'],
            'telefono' => $cliente['telefono'],
            'direccion' => $cliente['direccion']
        ),
        'productos' => $productos
    );

    $args = array(
        'body'        => json_encode($data),
        'headers'     => array('Content-Type' => 'application/json'),
        'method'      => 'POST',
        'data_format' => 'body',
        'timeout'     => 5 // Control de espera de 5 segundos
    );

    $response = wp_remote_post($url, $args);

    if (is_wp_error($response)) {
        error_log('[Roostech] Error al enviar factura: ' . $response->get_error_message());
    } else {
        $body = wp_remote_retrieve_body($response);
        error_log('[Roostech] Factura enviada exitosamente: ' . $body);
    }
}

// Activación manual con ?factura_test
add_action('init', function() {
    if (!isset($_GET['factura_test'])) {
        return;
    }

    error_log('[Roostech] Ejecutando envío manual de factura...');

    $cliente = array(
        'nombre' => 'Wilson Gallo',
        'tipo_documento' => 'CC',
        'numero_documento' => '79672899',
        'email' => 'wilson@example.com',
        'telefono' => '3001234567',
        'direccion' => 'Medellín, Colombia'
    );

    $productos = array(
        array('producto_id' => 1, 'cantidad' => 2),
        array('producto_id' => 2, 'cantidad' => 1)
    );

    roostech_enviar_factura($cliente, $productos);
});
?>
